<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common_lib extends CI_Controller {

	
}